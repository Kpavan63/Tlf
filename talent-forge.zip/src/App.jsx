"use client"

import { useState, useEffect } from "react"
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import { motion, AnimatePresence } from "framer-motion"
import { ParallaxProvider } from "react-scroll-parallax"
import { Toaster } from "react-hot-toast"
import Navbar from "./components/Navbar"
import Hero from "./components/Hero"
import Features from "./components/Features"
import Testimonials from "./components/Testimonials"
import Pricing from "./components/Pricing"
import Footer from "./components/Footer"
import LoadingScreen from "./components/LoadingScreen"
import BackgroundAnimation from "./components/BackgroundAnimation"
import "./App.css"

function App() {
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setLoading(false)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  return (
    <ParallaxProvider>
      <Router>
        <AnimatePresence mode="wait">
          {loading ? (
            <LoadingScreen key="loading" />
          ) : (
            <motion.div
              key="app"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="app"
            >
              <BackgroundAnimation />
              <Navbar />
              <Routes>
                <Route
                  path="/"
                  element={
                    <>
                      <Hero />
                      <Features />
                      <Testimonials />
                      <Pricing />
                    </>
                  }
                />
                {/* Add more routes as needed */}
              </Routes>
              <Footer />
              <Toaster position="bottom-right" />
            </motion.div>
          )}
        </AnimatePresence>
      </Router>
    </ParallaxProvider>
  )
}

export default App
