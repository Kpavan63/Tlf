"use client"

import { motion, useInView } from "framer-motion"
import { FiTarget, FiTrendingUp, FiUsers, FiAward } from "react-icons/fi"
import { useRef } from "react"
import { Parallax } from "react-scroll-parallax"

const Features = () => {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: false, amount: 0.2 })

  const features = [
    {
      icon: <FiTarget />,
      title: "Skill Assessment",
      description: "Identify your strengths and areas for improvement with our comprehensive skill assessment tools.",
      color: "#0088ff",
    },
    {
      icon: <FiTrendingUp />,
      title: "Personalized Growth Path",
      description: "Get a customized learning journey based on your goals, current skills, and industry demands.",
      color: "#ff6b00",
    },
    {
      icon: <FiUsers />,
      title: "Mentorship Network",
      description: "Connect with industry experts and peers for guidance, feedback, and collaboration opportunities.",
      color: "#00c853",
    },
    {
      icon: <FiAward />,
      title: "Certification Programs",
      description: "Earn industry-recognized certifications to validate your skills and boost your career prospects.",
      color: "#aa00ff",
    },
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5, type: "spring", stiffness: 100 },
    },
  }

  return (
    <section className="features-section" id="features" ref={ref}>
      <Parallax speed={-10} className="features-parallax-bg">
        <div className="features-bg-circle circle-1"></div>
        <div className="features-bg-circle circle-2"></div>
        <div className="features-bg-circle circle-3"></div>
      </Parallax>

      <div className="container">
        <motion.div
          className="section-header"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="section-title">How TalentForge Works</h2>
          <p className="section-subtitle">
            Our comprehensive platform offers everything you need to develop and showcase your talents
          </p>
        </motion.div>

        <motion.div
          className="features-grid"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {features.map((feature, index) => (
            <motion.div
              key={index}
              className="feature-card"
              variants={itemVariants}
              whileHover={{
                y: -10,
                boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
                transition: { duration: 0.3 },
              }}
            >
              <div className="feature-icon" style={{ backgroundColor: `${feature.color}20`, color: feature.color }}>
                {feature.icon}
              </div>
              <h3 className="feature-title">{feature.title}</h3>
              <p className="feature-description">{feature.description}</p>
              <motion.div
                className="feature-card-overlay"
                initial={{ opacity: 0 }}
                whileHover={{ opacity: 1 }}
                style={{ borderColor: feature.color }}
              />
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          className="features-cta"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <button className="btn-primary">Explore All Features</button>
        </motion.div>
      </div>
    </section>
  )
}

export default Features
