"use client"

import { useState, useEffect, useRef } from "react"
import { motion, useInView, AnimatePresence } from "framer-motion"
import { FiChevronLeft, FiChevronRight, FiStar } from "react-icons/fi"
import { Parallax } from "react-scroll-parallax"

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [width, setWidth] = useState(0)
  const carousel = useRef()
  const sectionRef = useRef(null)
  const isInView = useInView(sectionRef, { once: false, amount: 0.2 })

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "UX Designer",
      company: "DesignHub",
      image: "/placeholder.svg?height=100&width=100",
      text: "TalentForge transformed my career. The personalized learning path and mentor connections helped me land my dream job within 3 months.",
      rating: 5,
    },
    {
      name: "Michael Chen",
      role: "Software Engineer",
      company: "TechGrowth",
      image: "/placeholder.svg?height=100&width=100",
      text: "The skill assessments were eye-opening. I discovered gaps in my knowledge that I didn't know existed, and TalentForge provided exactly what I needed to fill them.",
      rating: 5,
    },
    {
      name: "Priya Patel",
      role: "Marketing Director",
      company: "BrandWave",
      image: "/placeholder.svg?height=100&width=100",
      text: "As someone looking to pivot careers, TalentForge gave me the structure and resources I needed. Their certification programs are recognized everywhere.",
      rating: 4,
    },
    {
      name: "James Wilson",
      role: "Data Scientist",
      company: "AnalyticsPro",
      image: "/placeholder.svg?height=100&width=100",
      text: "The community aspect of TalentForge is incredible. I've made valuable connections and even found my current job through a fellow member.",
      rating: 5,
    },
  ]

  useEffect(() => {
    if (carousel.current) {
      setWidth(carousel.current.scrollWidth - carousel.current.offsetWidth)
    }
  }, [])

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1))
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1))
  }

  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide()
    }, 5000)

    return () => clearInterval(interval)
  }, [currentIndex])

  return (
    <section className="testimonials-section" id="testimonials" ref={sectionRef}>
      <Parallax speed={-5} className="testimonials-parallax-bg">
        <div className="testimonials-bg-shape shape-1"></div>
        <div className="testimonials-bg-shape shape-2"></div>
      </Parallax>

      <div className="container">
        <motion.div
          className="section-header"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="section-title">What Our Users Say</h2>
          <p className="section-subtitle">
            Join thousands of professionals who have transformed their careers with TalentForge
          </p>
        </motion.div>

        <div className="testimonials-carousel-container">
          <motion.button
            className="carousel-button prev"
            onClick={prevSlide}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <FiChevronLeft />
          </motion.button>

          <motion.div ref={carousel} className="testimonials-carousel" whileTap={{ cursor: "grabbing" }}>
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                className="testimonial-card active"
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.5 }}
              >
                <div className="testimonial-content">
                  <div className="testimonial-rating">
                    {[...Array(5)].map((_, i) => (
                      <FiStar
                        key={i}
                        className={i < testimonials[currentIndex].rating ? "star-filled" : "star-empty"}
                      />
                    ))}
                  </div>
                  <p className="testimonial-text">"{testimonials[currentIndex].text}"</p>
                  <div className="testimonial-author">
                    <motion.img
                      src={testimonials[currentIndex].image || "/placeholder.svg"}
                      alt={testimonials[currentIndex].name}
                      className="author-image"
                      whileHover={{ scale: 1.1 }}
                    />
                    <div className="author-info">
                      <h4 className="author-name">{testimonials[currentIndex].name}</h4>
                      <p className="author-role">
                        {testimonials[currentIndex].role} at {testimonials[currentIndex].company}
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </motion.div>

          <motion.button
            className="carousel-button next"
            onClick={nextSlide}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <FiChevronRight />
          </motion.button>
        </div>

        <div className="carousel-dots">
          {testimonials.map((_, index) => (
            <motion.button
              key={index}
              className={`dot ${index === currentIndex ? "active" : ""}`}
              onClick={() => setCurrentIndex(index)}
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
              animate={index === currentIndex ? { scale: 1.2 } : { scale: 1 }}
            />
          ))}
        </div>

        <motion.div
          className="testimonials-cta"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <button className="btn-secondary">Read More Success Stories</button>
        </motion.div>
      </div>
    </section>
  )
}

export default Testimonials
