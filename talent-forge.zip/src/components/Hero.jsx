"use client"

import { motion } from "framer-motion"
import { FiArrowRight } from "react-icons/fi"
import { Parallax } from "react-scroll-parallax"
import { TypeAnimation } from "react-type-animation"
import toast from "react-hot-toast"

const Hero = () => {
  const handleGetStarted = () => {
    toast.success("Welcome to TalentForge! Let's get started on your journey.")
  }

  return (
    <section className="hero-section">
      <div className="hero-container">
        <motion.div
          className="hero-content"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          <motion.h1
            className="hero-title"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.7 }}
          >
            Forge Your Future{" "}
            <TypeAnimation
              sequence={["Talent", 2000, "Career", 2000, "Skills", 2000, "Potential", 2000]}
              wrapper="span"
              speed={50}
              className="highlight"
              repeat={Number.POSITIVE_INFINITY}
            />
          </motion.h1>
          <motion.p
            className="hero-subtitle"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.9 }}
          >
            Discover, develop, and deploy your skills with our cutting-edge talent development platform. Join thousands
            of professionals who have transformed their careers with TalentForge.
          </motion.p>
          <motion.div
            className="hero-buttons"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.1 }}
          >
            <button className="btn-primary" onClick={handleGetStarted}>
              Get Started <FiArrowRight className="btn-icon" />
            </button>
            <button className="btn-secondary">Learn More</button>
          </motion.div>
          <motion.div
            className="hero-stats"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.3 }}
          >
            <div className="stat-item">
              <motion.span
                className="stat-number"
                initial={{ scale: 0.5 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.5, delay: 1.5 }}
              >
                10K+
              </motion.span>
              <span className="stat-label">Users</span>
            </div>
            <div className="stat-item">
              <motion.span
                className="stat-number"
                initial={{ scale: 0.5 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.5, delay: 1.7 }}
              >
                500+
              </motion.span>
              <span className="stat-label">Courses</span>
            </div>
            <div className="stat-item">
              <motion.span
                className="stat-number"
                initial={{ scale: 0.5 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.5, delay: 1.9 }}
              >
                95%
              </motion.span>
              <span className="stat-label">Success Rate</span>
            </div>
          </motion.div>
        </motion.div>

        <Parallax translateY={[-20, 20]} className="hero-image-wrapper">
          <motion.div
            className="hero-image"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.8 }}
          >
            <div className="image-container">
              <div className="blob-shape"></div>
              <motion.img
                src="/placeholder.svg?height=500&width=500"
                alt="TalentForge Platform"
                whileHover={{
                  rotate: 5,
                  scale: 1.05,
                  transition: { duration: 0.3 },
                }}
                drag
                dragConstraints={{
                  top: -10,
                  left: -10,
                  right: 10,
                  bottom: 10,
                }}
              />

              <div className="floating-elements">
                <motion.div
                  className="floating-card card-1"
                  animate={{
                    y: [0, -15, 0],
                    rotate: [0, 5, 0],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                  }}
                >
                  <div className="card-icon">🚀</div>
                  <div className="card-text">Skills Boost</div>
                </motion.div>

                <motion.div
                  className="floating-card card-2"
                  animate={{
                    y: [0, 15, 0],
                    rotate: [0, -5, 0],
                  }}
                  transition={{
                    duration: 5,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                    delay: 0.5,
                  }}
                >
                  <div className="card-icon">🏆</div>
                  <div className="card-text">Career Growth</div>
                </motion.div>

                <motion.div
                  className="floating-card card-3"
                  animate={{
                    y: [0, -10, 0],
                    x: [0, 10, 0],
                  }}
                  transition={{
                    duration: 4.5,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                    delay: 1,
                  }}
                >
                  <div className="card-icon">💡</div>
                  <div className="card-text">Innovation</div>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </Parallax>
      </div>

      <div className="hero-wave">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
          <path
            fill="#f0f7ff"
            fillOpacity="1"
            d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,149.3C960,160,1056,160,1152,138.7C1248,117,1344,75,1392,53.3L1440,32L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
          ></path>
        </svg>
      </div>

      <div className="scroll-indicator">
        <motion.div
          animate={{
            y: [0, 10, 0],
          }}
          transition={{
            duration: 1.5,
            repeat: Number.POSITIVE_INFINITY,
            ease: "easeInOut",
          }}
        >
          <span>Scroll Down</span>
          <div className="scroll-arrow">↓</div>
        </motion.div>
      </div>
    </section>
  )
}

export default Hero
