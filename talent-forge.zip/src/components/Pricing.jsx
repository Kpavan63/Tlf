"use client"

import { useState, useRef } from "react"
import { motion, useInView } from "framer-motion"
import { FiCheck, FiX } from "react-icons/fi"
import { Parallax } from "react-scroll-parallax"
import toast from "react-hot-toast"

const Pricing = () => {
  const [annual, setAnnual] = useState(false)
  const sectionRef = useRef(null)
  const isInView = useInView(sectionRef, { once: false, amount: 0.2 })

  const plans = [
    {
      name: "Free",
      monthlyPrice: 0,
      annualPrice: 0,
      features: [
        { text: "Basic skill assessment", included: true },
        { text: "Limited course access", included: true },
        { text: "Community forum access", included: true },
        { text: "Personal profile", included: true },
        { text: "Mentor sessions", included: false },
        { text: "Certification preparation", included: false },
        { text: "Job board access", included: false },
      ],
      cta: "Get Started",
      popular: false,
      color: "#6c757d",
    },
    {
      name: "Pro",
      monthlyPrice: 19,
      annualPrice: 190,
      features: [
        { text: "Advanced skill assessment", included: true },
        { text: "Full course library access", included: true },
        { text: "Community forum access", included: true },
        { text: "Personal profile", included: true },
        { text: "1 mentor session monthly", included: true },
        { text: "Certification preparation", included: true },
        { text: "Job board access", included: true },
      ],
      cta: "Start Pro Plan",
      popular: true,
      color: "#0088ff",
    },
    {
      name: "Enterprise",
      monthlyPrice: 49,
      annualPrice: 490,
      features: [
        { text: "Custom skill assessments", included: true },
        { text: "Unlimited course access", included: true },
        { text: "Community forum access", included: true },
        { text: "Personal profile", included: true },
        { text: "Weekly mentor sessions", included: true },
        { text: "All certifications included", included: true },
        { text: "Career coaching", included: true },
      ],
      cta: "Contact Sales",
      popular: false,
      color: "#aa00ff",
    },
  ]

  const handlePlanSelect = (plan) => {
    toast.success(
      `${plan.name} plan selected! ${plan.name === "Free" ? "Get started now!" : "Redirecting to checkout..."}`,
    )
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5, type: "spring", stiffness: 100 },
    },
  }

  return (
    <section className="pricing-section" id="pricing" ref={sectionRef}>
      <Parallax speed={-5} className="pricing-parallax-bg">
        <div className="pricing-bg-shape"></div>
      </Parallax>

      <div className="container">
        <motion.div
          className="section-header"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="section-title">Simple, Transparent Pricing</h2>
          <p className="section-subtitle">Choose the plan that fits your needs</p>

          <div className="pricing-toggle">
            <span className={!annual ? "active" : ""}>Monthly</span>
            <label className="switch">
              <input type="checkbox" checked={annual} onChange={() => setAnnual(!annual)} />
              <span className="slider round"></span>
            </label>
            <span className={annual ? "active" : ""}>
              Annual <span className="discount">Save 20%</span>
            </span>
          </div>
        </motion.div>

        <motion.div
          className="pricing-cards"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              className={`pricing-card ${plan.popular ? "popular" : ""}`}
              variants={itemVariants}
              whileHover={{
                y: -10,
                boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
                transition: { duration: 0.3 },
              }}
              style={{
                borderTopColor: plan.popular ? plan.color : "transparent",
                borderTopWidth: plan.popular ? "4px" : "0",
              }}
            >
              {plan.popular && (
                <div className="popular-badge" style={{ backgroundColor: plan.color }}>
                  Most Popular
                </div>
              )}
              <h3 className="plan-name">{plan.name}</h3>
              <div className="plan-price">
                <span className="currency">$</span>
                <span className="amount">{annual ? plan.annualPrice : plan.monthlyPrice}</span>
                <span className="period">/{annual ? "year" : "month"}</span>
              </div>
              <ul className="plan-features">
                {plan.features.map((feature, i) => (
                  <li key={i} className={`feature-item ${!feature.included ? "disabled" : ""}`}>
                    {feature.included ? (
                      <FiCheck className="feature-icon included" />
                    ) : (
                      <FiX className="feature-icon not-included" />
                    )}
                    <span>{feature.text}</span>
                  </li>
                ))}
              </ul>
              <motion.button
                className={`plan-cta ${plan.popular ? "primary" : "secondary"}`}
                style={{
                  backgroundColor: plan.popular ? plan.color : "transparent",
                  borderColor: plan.color,
                  color: plan.popular ? "white" : plan.color,
                }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handlePlanSelect(plan)}
              >
                {plan.cta}
              </motion.button>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          className="pricing-guarantee"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <p>All plans include a 14-day money-back guarantee</p>
        </motion.div>
      </div>
    </section>
  )
}

export default Pricing
