"use client"

import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import { motion } from "framer-motion"
import { FiMenu, FiX } from "react-icons/fi"

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true)
      } else {
        setScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const toggleMenu = () => setIsOpen(!isOpen)

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "Services", path: "/services" },
    { name: "About", path: "/about" },
    { name: "Testimonials", path: "/testimonials" },
    { name: "Contact", path: "/contact" },
  ]

  const navVariants = {
    hidden: { y: -100, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5,
        staggerChildren: 0.1,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { y: -20, opacity: 0 },
    visible: { y: 0, opacity: 1 },
  }

  return (
    <motion.nav
      className={`navbar ${scrolled ? "scrolled" : ""}`}
      variants={navVariants}
      initial="hidden"
      animate="visible"
    >
      <div className="navbar-container">
        <Link to="/" className="navbar-logo">
          <motion.div className="logo-circle small" whileHover={{ scale: 1.1, rotate: 5 }} whileTap={{ scale: 0.9 }}>
            <span className="logo-text small">TF</span>
          </motion.div>
          <motion.span
            className="brand-name-nav"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            TalentForge
          </motion.span>
        </Link>

        <motion.div className="menu-icon" onClick={toggleMenu} whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
          {isOpen ? <FiX /> : <FiMenu />}
        </motion.div>

        <motion.ul className={`nav-menu ${isOpen ? "active" : ""}`} variants={navVariants}>
          {navLinks.map((link, index) => (
            <motion.li
              key={index}
              className="nav-item"
              variants={itemVariants}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <Link to={link.path} className="nav-link" onClick={() => setIsOpen(false)}>
                {link.name}
              </Link>
            </motion.li>
          ))}
          <motion.li
            className="nav-item"
            variants={itemVariants}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            <Link to="/login" className="nav-button">
              Log In
            </Link>
          </motion.li>
          <motion.li
            className="nav-item"
            variants={itemVariants}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            <Link to="/signup" className="nav-button primary">
              Sign Up
            </Link>
          </motion.li>
        </motion.ul>
      </div>
    </motion.nav>
  )
}

export default Navbar
