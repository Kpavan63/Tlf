"use client"

import { Link } from "react-router-dom"
import { FiTwitter, FiInstagram, FiLinkedin, FiFacebook, FiYoutube } from "react-icons/fi"
import { motion } from "framer-motion"

const Footer = () => {
  const currentYear = new Date().getFullYear()

  const socialVariants = {
    hover: { y: -5, scale: 1.1 },
  }

  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-top">
          <div className="footer-brand">
            <Link to="/" className="footer-logo">
              <motion.div className="logo-circle small" whileHover={{ scale: 1.1, rotate: 5 }}>
                <span className="logo-text small">TF</span>
              </motion.div>
              <span className="brand-name-footer">TalentForge</span>
            </Link>
            <p className="footer-tagline">Forge your future with the skills that matter</p>
            <div className="footer-social">
              <motion.a
                href="#"
                className="social-link"
                aria-label="Twitter"
                variants={socialVariants}
                whileHover="hover"
              >
                <FiTwitter />
              </motion.a>
              <motion.a
                href="#"
                className="social-link"
                aria-label="Instagram"
                variants={socialVariants}
                whileHover="hover"
              >
                <FiInstagram />
              </motion.a>
              <motion.a
                href="#"
                className="social-link"
                aria-label="LinkedIn"
                variants={socialVariants}
                whileHover="hover"
              >
                <FiLinkedin />
              </motion.a>
              <motion.a
                href="#"
                className="social-link"
                aria-label="Facebook"
                variants={socialVariants}
                whileHover="hover"
              >
                <FiFacebook />
              </motion.a>
              <motion.a
                href="#"
                className="social-link"
                aria-label="YouTube"
                variants={socialVariants}
                whileHover="hover"
              >
                <FiYoutube />
              </motion.a>
            </div>
          </div>

          <div className="footer-links">
            <div className="footer-links-column">
              <h4 className="footer-links-title">Platform</h4>
              <ul className="footer-links-list">
                <li>
                  <Link to="/features">Features</Link>
                </li>
                <li>
                  <Link to="/pricing">Pricing</Link>
                </li>
                <li>
                  <Link to="/testimonials">Testimonials</Link>
                </li>
                <li>
                  <Link to="/certifications">Certifications</Link>
                </li>
              </ul>
            </div>

            <div className="footer-links-column">
              <h4 className="footer-links-title">Company</h4>
              <ul className="footer-links-list">
                <li>
                  <Link to="/about">About Us</Link>
                </li>
                <li>
                  <Link to="/careers">Careers</Link>
                </li>
                <li>
                  <Link to="/blog">Blog</Link>
                </li>
                <li>
                  <Link to="/contact">Contact</Link>
                </li>
              </ul>
            </div>

            <div className="footer-links-column">
              <h4 className="footer-links-title">Resources</h4>
              <ul className="footer-links-list">
                <li>
                  <Link to="/help">Help Center</Link>
                </li>
                <li>
                  <Link to="/guides">Guides</Link>
                </li>
                <li>
                  <Link to="/events">Events</Link>
                </li>
                <li>
                  <Link to="/community">Community</Link>
                </li>
              </ul>
            </div>

            <div className="footer-links-column">
              <h4 className="footer-links-title">Legal</h4>
              <ul className="footer-links-list">
                <li>
                  <Link to="/terms">Terms of Service</Link>
                </li>
                <li>
                  <Link to="/privacy">Privacy Policy</Link>
                </li>
                <li>
                  <Link to="/cookies">Cookie Policy</Link>
                </li>
                <li>
                  <Link to="/security">Security</Link>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="footer-bottom">
          <p className="footer-copyright">&copy; {currentYear} TalentForge. All rights reserved.</p>
          <div className="footer-language">
            <select name="language" id="language-select">
              <option value="en">English</option>
              <option value="es">Español</option>
              <option value="fr">Français</option>
              <option value="de">Deutsch</option>
            </select>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer
