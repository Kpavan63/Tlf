# TalentForge - Modern Talent Development Platform

A modern, responsive web application for talent development with advanced UI/UX features.

## Features

- Modern UI with parallax scrolling effects
- Interactive animations and micro-interactions
- Responsive design for all devices
- Background particle animations
- Interactive card designs
- Type animations

## Technologies Used

- React
- Vite
- Framer Motion
- React Router
- React Scroll Parallax
- React Type Animation
- React Hot Toast
- React Icons

## Getting Started

1. Clone the repository
2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`
3. Run the development server:
   \`\`\`bash
   npm run dev
   \`\`\`
4. Build for production:
   \`\`\`bash
   npm run build
   \`\`\`

## Deployment

This project can be easily deployed to platforms like Vercel, Netlify, or GitHub Pages.

### Deploying to Vercel

1. Push your code to a GitHub repository
2. Connect your repository to Vercel
3. Vercel will automatically detect Vite and set up the build configuration

### Deploying to Netlify

1. Push your code to a GitHub repository
2. Connect your repository to Netlify
3. Set the build command to `npm run build`
4. Set the publish directory to `dist`

## License

MIT
